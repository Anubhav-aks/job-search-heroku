import { Component, OnInit } from '@angular/core';

import {Model} from '../model/model';
import{ AuthService } from '../auth.service';
import{ Router } from '@angular/router';
@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

  ngOnInit(): void {
  }
//   public districts=['Bhagalpur','Firozpur','Patna'];
//   public userModel= new Model('','','',null,'',null,'','',false);
//   public itHasError=true;
//   public errorMsg="";
//   constructor(private auth:AuthService,private router:Router){}
//   hasError(value)
// {
// if(value==='default')
// {
// this.itHasError=true;
// }
// else{
//   this.itHasError=false;
// }
// }
// onSubmit()
// {

//   //console.log(this.userModel
// this.auth.register(this.userModel)
// .subscribe(
//   res=>{console.log(res)
//  localStorage.setItem('token',res.token),
// this.router.navigate(['books'])},
//   err=>console.log(err)
// )
    
}


