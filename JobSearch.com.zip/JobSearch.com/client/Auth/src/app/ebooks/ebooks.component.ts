import { Component, OnInit } from '@angular/core';

import{ BookService } from '../book.service';
import { Router } from '@angular/router'


@Component({
  selector: 'app-ebooks',
  templateUrl: './ebooks.component.html',
  styleUrls: ['./ebooks.component.css']
})
export class EbooksComponent implements OnInit {
 books=[];
  constructor(private book:BookService,private router:Router) { }

  ngOnInit(){
    this.book.getEbooks().subscribe(
      res=>this.books=res,
      err=>console.log=err
    )
  }
  onApply(){
  this.router.navigate(['login'])
  }

}
