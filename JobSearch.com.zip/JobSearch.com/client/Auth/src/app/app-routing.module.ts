import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';
import { BooksComponent } from './books/books.component';
import { EbooksComponent } from './ebooks/ebooks.component';
import { NoPageFoundComponent } from './no-page-found/no-page-found.component';
import { AuthGuard } from './auth.guard';
import { TestComponent } from './test/test.component';

const routes: Routes = [{path:"",redirectTo:'/home',pathMatch:'full'},
{path:'home',component:EbooksComponent},
{path:'profile',component:BooksComponent
, canActivate:[AuthGuard],children:[{path:'apply',component:TestComponent}]
},
{path:'login',component:LoginComponent},
{path:'registration',component:RegistrationComponent},
{path:'**',component:NoPageFoundComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
