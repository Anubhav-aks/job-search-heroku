export class Model{
 
 constructor(
    public name:string,
    public email:string,
    public password:string,
    public phone:number,
   public qualification:string,
    public age:number,
    public  district:string,
    public  profile:string,
    public subscribe:boolean
){
   
}
}
export class User {
    constructor(
        public name:string,
        public email :string,
        public phone:number,
       
        public age:number,
        public  district:string,
        public  timeprefrence:string,
        public subscribe:boolean
    ){
       
    }
}