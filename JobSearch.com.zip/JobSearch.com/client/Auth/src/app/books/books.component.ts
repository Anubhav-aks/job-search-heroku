import { Component, OnInit } from '@angular/core';

import { BookService } from '../book.service'
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { Model } from '../model/model';


@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit {
  books = [];
  constructor(private book: BookService, private router: Router, private auth: AuthService) { }
  profile = "Your Profile";
  success = false;
  public detail: Model;
  ngOnInit() {
    this.book.getBooks().subscribe(
      res => { this.books = res },
      err => {

        if (err.status === 401) {
          return this.router.navigate(['/login'])
        }

      });
   

  }
  onSuccess() {
    this.success = true;
  }

}
