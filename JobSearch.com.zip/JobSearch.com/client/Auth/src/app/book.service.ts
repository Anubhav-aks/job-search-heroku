import { Injectable } from '@angular/core';

import{ HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class BookService {

  constructor(private http:HttpClient) { }
readonly _eBooksUrl='http://localhost:3000/auths/ebooks';
readonly _booksUrl='http://localhost:3000/auths/books';

getEbooks(){
 return this.http.get<any>(this._eBooksUrl);
}
getBooks(){
 return this.http.get<any>(this._booksUrl);
}

}
