const mongoose = require('mongoose');
const express = require('express');
const jwt = require('jsonwebtoken')
const router = express.Router();
const { Auth } = require('../model/Auth.js')

router.get('/', (req, res) => {
  Auth.find((err, doc) => {
    if (!err) {
      res.send(doc);
    }
    else {
      console.log('Error:' + JSON.stringify(err, undefined, 2))
    }
  })
})

function verifyToken(req, res, next) {
  if (!req.headers.authorization) {
    res.status(401).send('Unauthorazed Request!')
  }
  let token = req.headers.authorization.split(' ')[1]
  if (token === 'null') {
    res.status(401).send('Unauthorazed Request!')
  }
  let payload = jwt.verify(token, 'secretKey')
  if (!payload) {
    res.status(401).send('Unauthorazed Request!')
  }
  req.userId = payload.subject
  next()
}
router.post('/registration', (req, res) => {
  let userData = req.body;
  let user = new Auth(userData);
  user.save((err, doc) => {
    if (!err) {
      let payload = { subject: doc._id };
      let token = jwt.sign(payload, 'secretKey')
      res.status(200).send({ token });
    }
    else {
      console.log('Error:' + JSON.stringify(err, undefined, 2))
    }

  })
})
router.post('/login', (req, res) => {
  let userData = req.body;

  Auth.findOne({ email: userData.email }, (err, doc) => {
    if (err) {
      console.log(err);
    }
    else {
      if (!doc) {
        res.status(401).send("No Record Found!")
      }
      else {
        if (doc.password !== userData.password) {
          res.status(401).send("Wrong Password!")
        }
        else {
          let payload = { subject: doc._id };
          let token = jwt.sign(payload, 'secretKey')
          res.status(200).send({ token });
          
        }
      }
    }
  })
})

router.get('/books', verifyToken, (req, res) => {
  let books = [{
    "_id": "1",
    "name": "Sales Man",
    "description": "Tata Sky",
    "date": "2020-05-23T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "2",
    "name": "Software Developer",
    "description": "IBM",
    "date": "2020-06-20T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "3",
    "name": "Automation Engineer",
    "description": "Rockwell Automation",
    "date": "2020-06-11T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "4",
    "name": "Angular Developer",
    "description": "Google",
    "date": "2020-07-13T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "5",
    "name": "Sales Manager",
    "description": "Usha",
    "date": "2021-04-23T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "6",
    "name": "HR",
    "description": "HiTech",
    "date": "2020-08-23T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "7",
    "name": "Sales Man",
    "description": "Tata Sky",
    "date": "2020-05-23T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "8",
    "name": "Software Developer",
    "description": "IBM",
    "date": "2020-06-20T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "9",
    "name": "Automation Engineer",
    "description": "Rockwell Automation",
    "date": "2020-06-15T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "10",
    "name": "Angular Developer",
    "description": "Google",
    "date": "2020-07-13T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "11",
    "name": "Sales Manager",
    "description": "Usha",
    "date": "2021-04-23T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "12",
    "name": "HR",
    "description": "HiTech",
    "date": "2020-08-23T18:25:43.511Z",
    "last": "Last date of application"
  }, {
    "_id": "13",
    "name": "Sales Man",
    "description": "Tata Sky",
    "date": "2020-05-23T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "14",
    "name": "Software Developer",
    "description": "IBM",
    "date": "2020-06-20T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "15",
    "name": "Automation Engineer",
    "description": "Rockwell Automation",
    "date": "2020-06-15T18:25:43.511Z",
    "last": "Last date of application"
  },
  ]

  res.json(books);
})
router.get('/eBooks', (req, res) => {
  let ebooks = [{
    "_id": "1",
    "name": "Sales Man",
    "description": "Tata Sky",
    "date": "2020-05-23T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "2",
    "name": "Software Developer",
    "description": "IBM",
    "date": "2020-06-20T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "3",
    "name": "Automation Engineer",
    "description": "Rockwell Automation",
    "date": "2020-06-11T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "4",
    "name": "Angular Developer",
    "description": "Google",
    "date": "2020-07-13T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "5",
    "name": "Sales Manager",
    "description": "Usha",
    "date": "2021-04-23T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "6",
    "name": "HR",
    "description": "HiTech",
    "date": "2020-08-23T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "7",
    "name": "Sales Man",
    "description": "Tata Sky",
    "date": "2020-05-23T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "8",
    "name": "Software Developer",
    "description": "IBM",
    "date": "2020-06-20T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "9",
    "name": "Automation Engineer",
    "description": "Rockwell Automation",
    "date": "2020-06-15T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "10",
    "name": "Angular Developer",
    "description": "Google",
    "date": "2020-07-13T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "11",
    "name": "Sales Manager",
    "description": "Usha",
    "date": "2021-04-23T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "12",
    "name": "HR",
    "description": "HiTech",
    "date": "2020-08-23T18:25:43.511Z",
    "last": "Last date of application"
  }, {
    "_id": "13",
    "name": "Sales Man",
    "description": "Tata Sky",
    "date": "2020-05-23T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "14",
    "name": "Software Developer",
    "description": "IBM",
    "date": "2020-06-20T18:25:43.511Z",
    "last": "Last date of application"
  },
  {
    "_id": "15",
    "name": "Automation Engineer",
    "description": "Rockwell Automation",
    "date": "2020-06-15T18:25:43.511Z",
    "last": "Last date of application"
  },
  ]
  res.json(ebooks);
})
module.exports = router;