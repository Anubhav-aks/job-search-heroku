const mongoose=require('mongoose');
var Auth=mongoose.model('Auth',{
    name:{type:String},
    email:{type:String},
    password:{type:String},
    phone:{type:Number},
    qualification:{type:String},
    age:{type:Number},
    district:{type:String},
    profile:{type:String},
    subscribe:{type:Boolean}
})
module.exports={Auth};
